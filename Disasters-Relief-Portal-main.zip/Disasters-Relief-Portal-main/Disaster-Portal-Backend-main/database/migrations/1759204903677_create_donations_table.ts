import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'donations'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.enum('donation_type', ['money', 'food', 'clothing', 'medical', 'shelter', 'other']).notNullable()
      table.float('amount').nullable()
      table.string('currency', 3).nullable()
      table.text('description').nullable()
      table.integer('quantity').nullable()
      table.string('unit').nullable()
      table.enum('status', ['pending', 'completed', 'failed', 'refunded']).notNullable().defaultTo('pending')
      table.string('payment_method').nullable()
      table.string('transaction_id').nullable()
      table.boolean('is_anonymous').notNullable().defaultTo(false)
      table.string('donor_name').nullable()
      table.string('donor_email').nullable()
      table.string('donor_phone').nullable()
      table.integer('donated_by').unsigned().nullable().references('id').inTable('users')
      table.integer('disaster_id').unsigned().nullable().references('id').inTable('disasters')
      table.integer('organization_id').unsigned().nullable().references('id').inTable('users')
      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}