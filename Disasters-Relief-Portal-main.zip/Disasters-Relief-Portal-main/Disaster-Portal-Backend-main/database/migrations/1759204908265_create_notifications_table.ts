import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'notifications'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.string('title').notNullable()
      table.text('message').notNullable()
      table.enum('type', ['disaster_alert', 'resource_update', 'volunteer_assignment', 'donation_received', 'general', 'emergency']).notNullable()
      table.enum('priority', ['low', 'medium', 'high', 'critical']).notNullable()
      table.enum('target_audience', ['all', 'citizens', 'ngos', 'volunteers', 'specific_users']).notNullable()
      table.integer('recipient_id').unsigned().nullable().references('id').inTable('users')
      table.integer('disaster_id').unsigned().nullable().references('id').inTable('disasters')
      table.boolean('is_read').notNullable().defaultTo(false)
      table.integer('sent_by').unsigned().notNullable().references('id').inTable('users')
      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}