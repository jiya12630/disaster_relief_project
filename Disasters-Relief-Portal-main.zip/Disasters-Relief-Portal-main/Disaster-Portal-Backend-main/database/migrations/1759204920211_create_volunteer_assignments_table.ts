import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'volunteer_assignments'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.string('title').notNullable()
      table.text('description').notNullable()
      table.enum('task_type', ['rescue', 'medical_aid', 'food_distribution', 'shelter_setup', 'cleanup', 'coordination', 'other']).notNullable()
      table.enum('priority', ['low', 'medium', 'high', 'urgent']).notNullable()
      table.enum('status', ['open', 'assigned', 'in_progress', 'completed', 'cancelled']).notNullable().defaultTo('open')
      table.string('required_skills').nullable()
      table.integer('volunteers_needed').notNullable()
      table.integer('volunteers_assigned').notNullable().defaultTo(0)
      table.string('location').notNullable()
      table.float('latitude').nullable()
      table.float('longitude').nullable()
      table.timestamp('start_date').notNullable()
      table.timestamp('end_date').nullable()
      table.string('contact_person').notNullable()
      table.string('contact_phone').notNullable()
      table.integer('volunteer_id').unsigned().nullable().references('id').inTable('users')
      table.integer('disaster_id').unsigned().notNullable().references('id').inTable('disasters')
      table.integer('created_by').unsigned().notNullable().references('id').inTable('users')
      table.timestamp('assigned_at').nullable()
      table.timestamp('completed_at').nullable()
      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}