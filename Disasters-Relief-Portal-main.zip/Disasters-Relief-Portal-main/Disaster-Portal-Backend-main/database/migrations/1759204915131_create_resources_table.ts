import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'resources'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.string('title').notNullable()
      table.text('description').notNullable()
      table.enum('resource_type', ['food', 'shelter', 'medical', 'clothing', 'water', 'other']).notNullable()
      table.integer('quantity').notNullable()
      table.string('unit').notNullable()
      table.integer('available_quantity').notNullable()
      table.enum('status', ['available', 'reserved', 'distributed', 'expired']).notNullable().defaultTo('available')
      table.string('location').notNullable()
      table.float('latitude').nullable()
      table.float('longitude').nullable()
      table.string('contact_person').notNullable()
      table.string('contact_phone').notNullable()
      table.string('contact_email').nullable()
      table.timestamp('expiry_date').nullable()
      table.integer('provided_by').unsigned().notNullable().references('id').inTable('users')
      table.integer('disaster_id').unsigned().nullable().references('id').inTable('disasters')
      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}