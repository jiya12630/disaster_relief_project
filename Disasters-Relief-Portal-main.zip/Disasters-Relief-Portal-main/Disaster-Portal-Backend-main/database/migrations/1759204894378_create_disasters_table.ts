import { BaseSchema } from '@adonisjs/lucid/schema'

export default class extends BaseSchema {
  protected tableName = 'disasters'

  async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id')
      table.string('title').notNullable()
      table.text('description').notNullable()
      table.enum('disaster_type', ['flood', 'earthquake', 'fire', 'hurricane', 'tornado', 'tsunami', 'other']).notNullable()
      table.enum('severity', ['low', 'medium', 'high', 'critical']).notNullable()
      table.enum('status', ['reported', 'verified', 'active', 'resolved']).notNullable().defaultTo('reported')
      table.float('latitude').notNullable()
      table.float('longitude').notNullable()
      table.string('address').notNullable()
      table.string('city').notNullable()
      table.string('state').notNullable()
      table.integer('affected_people').nullable()
      table.float('estimated_damage').nullable()
      table.text('images').nullable()
      table.integer('reported_by').unsigned().notNullable().references('id').inTable('users')
      table.integer('verified_by').unsigned().nullable().references('id').inTable('users')
      table.timestamp('verified_at').nullable()
      table.timestamp('created_at').notNullable()
      table.timestamp('updated_at').nullable()
    })
  }

  async down() {
    this.schema.dropTable(this.tableName)
  }
}