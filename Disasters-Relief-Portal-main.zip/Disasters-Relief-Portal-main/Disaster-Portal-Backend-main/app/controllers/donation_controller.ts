import type { HttpContext } from '@adonisjs/core/http'
import Donation from '#models/donation'
import Notification from '#models/notification'
import { createDonationValidator, updateDonationValidator } from '../validators/donation.ts'

export default class DonationController {
  /**
   * Get all donations with pagination and filters
   */
  async index({ request, response }: HttpContext) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const donationType = request.input('donation_type')
    const status = request.input('status')
    const disasterId = request.input('disaster_id')
    const organizationId = request.input('organization_id')

    const query = Donation.query()
      .preload('donor', (query) => {
        query.select('id', 'fullName', 'email')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .preload('organization', (query) => {
        query.select('id', 'fullName', 'organizationName')
      })
      .orderBy('createdAt', 'desc')

    if (donationType) query.where('donationType', donationType)
    if (status) query.where('status', status)
    if (disasterId) query.where('disasterId', disasterId)
    if (organizationId) query.where('organizationId', organizationId)

    const donations = await query.paginate(page, limit)

    return response.ok({
      message: 'Donations retrieved successfully',
      data: donations
    })
  }

  /**
   * Create a new donation
   */
  async store({ auth, request, response }: HttpContext) {
    const user = auth.user // Optional authentication for donations
    const data = await request.validateUsing(createDonationValidator)

    const donation = await Donation.create({
      ...data,
      donatedBy: user?.id || null,
      status: 'pending'
    })

    // Create notification for donation received
    if (donation.organizationId) {
      await Notification.create({
        title: `New Donation Received`,
        message: `A ${donation.donationType} donation of ${donation.amount ? `${donation.currency} ${donation.amount}` : `${donation.quantity} ${donation.unit}`} has been received`,
        type: 'donation_received',
        priority: 'medium',
        targetAudience: 'specific_users',
        recipientId: donation.organizationId,
        disasterId: donation.disasterId,
        sentBy: user?.id || undefined,
        isRead: false
      })
    }

    await donation.load('donor')
    await donation.load('disaster')
    await donation.load('organization')

    return response.created({
      message: 'Donation created successfully',
      data: donation
    })
  }

  /**
   * Get donation by ID
   */
  async show({ params, response }: HttpContext) {
    const donation = await Donation.query()
      .where('id', params.id)
      .preload('donor', (query) => {
        query.select('id', 'fullName', 'email')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state', 'status')
      })
      .preload('organization', (query) => {
        query.select('id', 'fullName', 'organizationName', 'email')
      })
      .firstOrFail()

    return response.ok({
      message: 'Donation retrieved successfully',
      data: donation
    })
  }

  /**
   * Update donation status (for payment processing)
   */
  async update({ auth, params, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const donation = await Donation.findOrFail(params.id)

    // Only the donor or organization can update donation
    if (donation.donatedBy !== user.id && donation.organizationId !== user.id) {
      return response.forbidden({
        message: 'You can only update your own donations'
      })
    }

    const data = await request.validateUsing(updateDonationValidator)
    donation.merge(data)
    await donation.save()

    await donation.load('donor')
    await donation.load('disaster')
    await donation.load('organization')

    return response.ok({
      message: 'Donation updated successfully',
      data: donation
    })
  }

  /**
   * Process payment for donation
   */
  async processPayment({ params, request, response }: HttpContext) {
    const donation = await Donation.findOrFail(params.id)
    const { paymentMethod, transactionId } = request.only(['paymentMethod', 'transactionId'])

    if (donation.status !== 'pending') {
      return response.badRequest({
        message: 'Donation is not in pending status'
      })
    }

    // In a real application, you would integrate with payment gateway here
    // For now, we'll simulate payment processing
    donation.paymentMethod = paymentMethod
    donation.transactionId = transactionId
    donation.status = 'completed'
    await donation.save()

    // Create notification for successful payment
    if (donation.organizationId) {
      await Notification.create({
        title: `Donation Payment Completed`,
        message: `Payment for donation ${donation.id} has been completed successfully`,
        type: 'donation_received',
        priority: 'medium',
        targetAudience: 'specific_users',
        recipientId: donation.organizationId,
        disasterId: donation.disasterId,
        sentBy: donation.donatedBy ?? undefined,
        isRead: false
      })
    }

    return response.ok({
      message: 'Payment processed successfully',
      data: donation
    })
  }

  /**
   * Get user's donation history
   */
  async userDonations({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)

    const donations = await Donation.query()
      .where('donatedBy', user.id)
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .preload('organization', (query) => {
        query.select('id', 'fullName', 'organizationName')
      })
      .orderBy('createdAt', 'desc')
      .paginate(page, limit)

    return response.ok({
      message: 'User donations retrieved successfully',
      data: donations
    })
  }

  /**
   * Get donations received by organization
   */
  async organizationDonations({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'ngo') {
      return response.forbidden({
        message: 'Only NGOs can view received donations'
      })
    }

    const page = request.input('page', 1)
    const limit = request.input('limit', 20)

    const donations = await Donation.query()
      .where('organizationId', user.id)
      .preload('donor', (query) => {
        query.select('id', 'fullName', 'email')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .orderBy('createdAt', 'desc')
      .paginate(page, limit)

    return response.ok({
      message: 'Organization donations retrieved successfully',
      data: donations
    })
  }

  /**
   * Get donation statistics
   */
  async statistics({ response }: HttpContext) {
    const totalDonations = await Donation.query().count('* as total')
    const completedDonations = await Donation.query().where('status', 'completed').count('* as total')
    const totalAmount = await Donation.query()
      .where('status', 'completed')
      .where('donationType', 'money')
      .sum('amount as total')

    const donationsByType = await Donation.query()
      .select('donationType')
      .count('* as count')
      .groupBy('donationType')

    const donationsByStatus = await Donation.query()
      .select('status')
      .count('* as count')
      .groupBy('status')

    return response.ok({
      message: 'Donation statistics retrieved successfully',
      data: {
        total: totalDonations[0].$extras.total,
        completed: completedDonations[0].$extras.total,
        totalAmount: totalAmount[0].$extras.total || 0,
        byType: donationsByType,
        byStatus: donationsByStatus
      }
    })
  }
}