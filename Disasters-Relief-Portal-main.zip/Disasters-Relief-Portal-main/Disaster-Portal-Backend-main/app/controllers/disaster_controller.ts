import type { HttpContext } from '@adonisjs/core/http'
import Disaster from '#models/disaster'
import Notification from '#models/notification'
import { createDisasterValidator, updateDisasterValidator } from '../validators/disaster.ts'
import { DateTime } from 'luxon'

export default class DisasterController {
  /**
   * Get all disasters with pagination and filters
   */
  async index({ request, response }: HttpContext) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const status = request.input('status')
    const disasterType = request.input('disaster_type')
    const severity = request.input('severity')
    const city = request.input('city')

    const query = Disaster.query()
      .preload('reporter', (query) => {
        query.select('id', 'fullName', 'email', 'userType')
      })
      .orderBy('createdAt', 'desc')

    if (status) query.where('status', status)
    if (disasterType) query.where('disasterType', disasterType)
    if (severity) query.where('severity', severity)
    if (city) query.where('city', 'ILIKE', `%${city}%`)

    const disasters = await query.paginate(page, limit)

    return response.ok({
      message: 'Disasters retrieved successfully',
      data: disasters
    })
  }

  /**
   * Report a new disaster
   */
  async store({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const data = await request.validateUsing(createDisasterValidator)

    const disaster = await Disaster.create({
      ...data,
      reportedBy: user.id,
      status: 'reported'
    })

    // Create notification for disaster alert
    await Notification.create({
      title: `New Disaster Reported: ${disaster.title}`,
      message: `A ${disaster.disasterType} has been reported in ${disaster.city}, ${disaster.state}`,
      type: 'disaster_alert',
      priority: disaster.severity === 'critical' ? 'critical' : 'high',
      targetAudience: 'all',
      disasterId: disaster.id,
      sentBy: user.id,
      isRead: false
    })

    await disaster.load('reporter')

    return response.created({
      message: 'Disaster reported successfully',
      data: disaster
    })
  }

  /**
   * Get disaster by ID
   */
  async show({ params, response }: HttpContext) {
    const disaster = await Disaster.query()
      .where('id', params.id)
      .preload('reporter', (query) => {
        query.select('id', 'fullName', 'email', 'userType')
      })
      .preload('resources')
      .preload('volunteerAssignments')
      .firstOrFail()

    return response.ok({
      message: 'Disaster retrieved successfully',
      data: disaster
    })
  }

  /**
   * Update disaster status (for NGOs/admins)
   */
  async update({ auth, params, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const disaster = await Disaster.findOrFail(params.id)
    const data = await request.validateUsing(updateDisasterValidator)

    // Only NGOs and the original reporter can update disasters
    if (user.userType !== 'ngo' && disaster.reportedBy !== user.id) {
      return response.forbidden({
        message: 'You are not authorized to update this disaster'
      })
    }

    disaster.merge(data)
    
    // If status is being verified, set verification details
    if (data.status === 'verified' && user.userType === 'ngo') {
      disaster.verifiedBy = user.id
      disaster.verifiedAt = DateTime.now()
    }

    await disaster.save()
    await disaster.load('reporter')

    return response.ok({
      message: 'Disaster updated successfully',
      data: disaster
    })
  }

  /**
   * Get disasters near a location
   */
  async nearby({ request, response }: HttpContext) {
    const { latitude, longitude, radius = 50 } = request.qs()

    if (!latitude || !longitude) {
      return response.badRequest({
        message: 'Latitude and longitude are required'
      })
    }

    // Using Haversine formula to find nearby disasters
    const disasters = await Disaster.query()
      .select('*')
      .select(
        '*',
        Disaster.$knex.raw(`
          (6371 * acos(
            cos(radians(?)) * cos(radians(latitude)) * 
            cos(radians(longitude) - radians(?)) + 
            sin(radians(?)) * sin(radians(latitude))
          )) AS distance
        `, [latitude, longitude, latitude])
      )
      .havingRaw('distance < ?', [radius])
      .orderBy('distance', 'asc')
      .preload('reporter', (query) => {
        query.select('id', 'fullName', 'userType')
      })

    return response.ok({
      message: 'Nearby disasters retrieved successfully',
      data: disasters
    })
  }

  /**
   * Get disaster statistics
   */
  async statistics({ response }: HttpContext) {
    const totalDisasters = await Disaster.query().count('* as total')
    const activeDisasters = await Disaster.query().where('status', 'active').count('* as total')
    const resolvedDisasters = await Disaster.query().where('status', 'resolved').count('* as total')
    
    const disastersByType = await Disaster.query()
      .select('disasterType')
      .count('* as count')
      .groupBy('disasterType')

    const disastersBySeverity = await Disaster.query()
      .select('severity')
      .count('* as count')
      .groupBy('severity')

    return response.ok({
      message: 'Disaster statistics retrieved successfully',
      data: {
        total: totalDisasters[0].$extras.total,
        active: activeDisasters[0].$extras.total,
        resolved: resolvedDisasters[0].$extras.total,
        byType: disastersByType,
        bySeverity: disastersBySeverity
      }
    })
  }
}