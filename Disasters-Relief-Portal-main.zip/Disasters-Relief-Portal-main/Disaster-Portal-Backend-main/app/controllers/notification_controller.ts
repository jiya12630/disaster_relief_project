import type { HttpContext } from '@adonisjs/core/http'
import Notification from '#models/notification'
import { createNotificationValidator } from '../validators/notification.ts'

export default class NotificationController {
  /**
   * Get notifications for current user
   */
  async index({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const type = request.input('type')
    const priority = request.input('priority')
    const isRead = request.input('is_read')

    const query = Notification.query()
      .where((builder) => {
        builder
          .where('targetAudience', 'all')
          .orWhere('targetAudience', user.userType)
          .orWhere('recipientId', user.id)
      })
      .preload('sender', (query) => {
        query.select('id', 'fullName', 'organizationName', 'userType')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .orderBy('createdAt', 'desc')

    if (type) query.where('type', type)
    if (priority) query.where('priority', priority)
    if (isRead !== undefined) query.where('isRead', isRead === 'true')

    const notifications = await query.paginate(page, limit)

    return response.ok({
      message: 'Notifications retrieved successfully',
      data: notifications
    })
  }

  /**
   * Create a new notification (for NGOs/admins)
   */
  async store({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'ngo') {
      return response.forbidden({
        message: 'Only NGOs can create notifications'
      })
    }

    const data = await request.validateUsing(createNotificationValidator)

    const notification = await Notification.create({
      ...data,
      sentBy: user.id,
      isRead: false
    })

    await notification.load('sender')
    await notification.load('disaster')

    return response.created({
      message: 'Notification created successfully',
      data: notification
    })
  }

  /**
   * Mark notification as read
   */
  async markAsRead({ auth, params, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const notification = await Notification.findOrFail(params.id)

    // Check if user can mark this notification as read
    const canRead = notification.targetAudience === 'all' ||
                   (notification.targetAudience === 'citizens' && user.userType === 'citizen') ||
                   (notification.targetAudience === 'ngos' && user.userType === 'ngo') ||
                   (notification.targetAudience === 'volunteers' && user.userType === 'volunteer') ||
                   notification.recipientId === user.id

    if (!canRead) {
      return response.forbidden({
        message: 'You cannot mark this notification as read'
      })
    }

    notification.isRead = true
    await notification.save()

    return response.ok({
      message: 'Notification marked as read'
    })
  }

  /**
   * Mark all notifications as read for current user
   */
  async markAllAsRead({ auth, response }: HttpContext) {
    const user = auth.getUserOrFail()

    await Notification.query()
      .where((builder) => {
        builder
          .where('targetAudience', 'all')
          .orWhere('targetAudience', user.userType)
          .orWhere('recipientId', user.id)
      })
      .where('isRead', false)
      .update({ isRead: true })

    return response.ok({
      message: 'All notifications marked as read'
    })
  }

  /**
   * Get unread notification count
   */
  async unreadCount({ auth, response }: HttpContext) {
    const user = auth.getUserOrFail()

    const count = await Notification.query()
      .where((builder) => {
        builder
          .where('targetAudience', 'all')
          .orWhere('targetAudience', user.userType)
          .orWhere('recipientId', user.id)
      })
      .where('isRead', false)
      .count('* as total')

    return response.ok({
      message: 'Unread notification count retrieved',
      data: {
        unreadCount: count[0].$extras.total
      }
    })
  }

  /**
   * Get emergency alerts
   */
  async emergencyAlerts({ request, response }: HttpContext) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 10)

    const alerts = await Notification.query()
      .where('type', 'emergency')
      .orWhere('priority', 'critical')
      .preload('sender', (query) => {
        query.select('id', 'fullName', 'organizationName')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state', 'disasterType', 'severity')
      })
      .orderBy('createdAt', 'desc')
      .paginate(page, limit)

    return response.ok({
      message: 'Emergency alerts retrieved successfully',
      data: alerts
    })
  }

  /**
   * Send broadcast notification to all users
   */
  async broadcast({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'ngo') {
      return response.forbidden({
        message: 'Only NGOs can send broadcast notifications'
      })
    }

    const { title, message, type, priority, disasterId } = request.only([
      'title', 'message', 'type', 'priority', 'disasterId'
    ])

    const notification = await Notification.create({
      title,
      message,
      type: type || 'general',
      priority: priority || 'medium',
      targetAudience: 'all',
      disasterId,
      sentBy: user.id,
      isRead: false
    })

    await notification.load('sender')
    await notification.load('disaster')

    return response.created({
      message: 'Broadcast notification sent successfully',
      data: notification
    })
  }

  /**
   * Get notification statistics
   */
  async statistics({ response }: HttpContext) {
    const totalNotifications = await Notification.query().count('* as total')
    const unreadNotifications = await Notification.query().where('isRead', false).count('* as total')
    
    const notificationsByType = await Notification.query()
      .select('type')
      .count('* as count')
      .groupBy('type')

    const notificationsByPriority = await Notification.query()
      .select('priority')
      .count('* as count')
      .groupBy('priority')

    return response.ok({
      message: 'Notification statistics retrieved successfully',
      data: {
        total: totalNotifications[0].$extras.total,
        unread: unreadNotifications[0].$extras.total,
        byType: notificationsByType,
        byPriority: notificationsByPriority
      }
    })
  }
}