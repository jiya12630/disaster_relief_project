import type { HttpContext } from '@adonisjs/core/http'
import User from '#models/user'
import { loginValidator, registerValidator } from '../validators/auth.ts'

export default class AuthController {
  /**
   * Register a new user (citizen, NGO, or volunteer)
   */
  async register({ request, response }: HttpContext) {
    const data = await request.validateUsing(registerValidator)
    
    const user = await User.create({
      ...data,
      isVerified: data.userType === 'citizen' // Citizens are auto-verified, NGOs/volunteers need manual verification
    })

    const token = await User.accessTokens.create(user)

    return response.created({
      message: 'User registered successfully',
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        isVerified: user.isVerified
      },
      token: token.value!.release()
    })
  }

  /**
   * Login user
   */
  async login({ request, response }: HttpContext) {
    const { email, password } = await request.validateUsing(loginValidator)

    const user = await User.verifyCredentials(email, password)
    const token = await User.accessTokens.create(user)

    return response.ok({
      message: 'Logged in successfully',
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        isVerified: user.isVerified
      },
      token: token.value!.release()
    })
  }

  /**
   * Logout user
   */
  async logout({ auth, response }: HttpContext) {
    const user = auth.getUserOrFail()
    await User.accessTokens.delete(user, user.currentAccessToken.identifier)

    return response.ok({
      message: 'Logged out successfully'
    })
  }

  /**
   * Get current user profile
   */
  async me({ auth, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    return response.ok({
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        phone: user.phone,
        address: user.address,
        organizationName: user.organizationName,
        skills: user.skills,
        isVerified: user.isVerified
      }
    })
  }

  /**
   * Update user profile
   */
  async updateProfile({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const data = request.only([
      'fullName', 'phone', 'address', 'organizationName', 'skills'
    ])

    user.merge(data)
    await user.save()

    return response.ok({
      message: 'Profile updated successfully',
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        userType: user.userType,
        phone: user.phone,
        address: user.address,
        organizationName: user.organizationName,
        skills: user.skills,
        isVerified: user.isVerified
      }
    })
  }
}