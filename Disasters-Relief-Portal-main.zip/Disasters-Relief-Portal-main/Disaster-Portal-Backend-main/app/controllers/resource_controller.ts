import type { HttpContext } from '@adonisjs/core/http'
import Resource from '#models/resource'
import Notification from '#models/notification'
import { createResourceValidator, updateResourceValidator } from '../validators/resource.ts'
import { DateTime } from 'luxon'

export default class ResourceController {
  /**
   * Get all resources with pagination and filters
   */
  async index({ request, response }: HttpContext) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const resourceType = request.input('resource_type')
    const status = request.input('status')
    const location = request.input('location')
    const disasterId = request.input('disaster_id')

    const query = Resource.query()
      .preload('provider', (query) => {
        query.select('id', 'fullName', 'organizationName', 'userType')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .orderBy('createdAt', 'desc')

    if (resourceType) query.where('resourceType', resourceType)
    if (status) query.where('status', status)
    if (location) query.where('location', 'ILIKE', `%${location}%`)
    if (disasterId) query.where('disasterId', disasterId)

    const resources = await query.paginate(page, limit)

    return response.ok({
      message: 'Resources retrieved successfully',
      data: resources
    })
  }

  /**
   * Post a new resource (for NGOs)
   */
  async store({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'ngo') {
      return response.forbidden({
        message: 'Only NGOs can post resources'
      })
    }

    const data = await request.validateUsing(createResourceValidator)

    const resource = await Resource.create({
      ...data,
      expiryDate: data.expiryDate ? DateTime.fromJSDate(data.expiryDate) : undefined,
      providedBy: user.id,
      availableQuantity: data.quantity,
      status: 'available'
    })

    // Create notification for resource availability
    await Notification.create({
      title: `New Resource Available: ${resource.title}`,
      message: `${resource.resourceType} is now available in ${resource.location}`,
      type: 'resource_update',
      priority: 'medium',
      targetAudience: 'all',
      disasterId: resource.disasterId,
      sentBy: user.id,
      isRead: false
    })

    await resource.load('provider')
    await resource.load('disaster')

    return response.created({
      message: 'Resource posted successfully',
      data: resource
    })
  }

  /**
   * Get resource by ID
   */
  async show({ params, response }: HttpContext) {
    const resource = await Resource.query()
      .where('id', params.id)
      .preload('provider', (query) => {
        query.select('id', 'fullName', 'organizationName', 'userType', 'email', 'phone')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state', 'status')
      })
      .firstOrFail()

    return response.ok({
      message: 'Resource retrieved successfully',
      data: resource
    })
  }

  /**
   * Update resource availability
   */
  async update({ auth, params, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const resource = await Resource.findOrFail(params.id)

    // Only the resource provider can update it
    if (resource.providedBy !== user.id) {
      return response.forbidden({
        message: 'You can only update your own resources'
      })
    }

    const data = await request.validateUsing(updateResourceValidator)
    resource.merge({
      ...data,
      expiryDate: data.expiryDate ? DateTime.fromJSDate(data.expiryDate) : undefined
    })
    await resource.save()

    await resource.load('provider')
    await resource.load('disaster')

    return response.ok({
      message: 'Resource updated successfully',
      data: resource
    })
  }

  /**
   * Reserve a resource
   */
  async reserve({ auth, params, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const resource = await Resource.findOrFail(params.id)
    const { quantity } = request.only(['quantity'])

    if (resource.status !== 'available') {
      return response.badRequest({
        message: 'Resource is not available for reservation'
      })
    }

    if (quantity > resource.availableQuantity) {
      return response.badRequest({
        message: 'Requested quantity exceeds available quantity'
      })
    }

    resource.availableQuantity -= quantity
    if (resource.availableQuantity === 0) {
      resource.status = 'reserved'
    }

    await resource.save()

    // Create notification for resource provider
    await Notification.create({
      title: `Resource Reserved: ${resource.title}`,
      message: `${quantity} ${resource.unit} of ${resource.title} has been reserved by ${user.fullName}`,
      type: 'resource_update',
      priority: 'medium',
      targetAudience: 'specific_users',
      recipientId: resource.providedBy,
      sentBy: user.id,
      isRead: false
    })

    return response.ok({
      message: 'Resource reserved successfully',
      data: {
        reservedQuantity: quantity,
        remainingQuantity: resource.availableQuantity
      }
    })
  }

  /**
   * Get resources near a location
   */
  async nearby({ request, response }: HttpContext) {
    const { latitude, longitude, radius = 50, resource_type } = request.qs()

    if (!latitude || !longitude) {
      return response.badRequest({
        message: 'Latitude and longitude are required'
      })
    }

    const query = Resource.query()
      .select('*')
      .select(
        Resource.$knexRaw(`
          (6371 * acos(
            cos(radians(?)) * cos(radians(latitude)) * 
            cos(radians(longitude) - radians(?)) + 
            sin(radians(?)) * sin(radians(latitude))
          )) AS distance
        `, [latitude, longitude, latitude])
      )
      .where('status', 'available')
      .havingRaw('distance < ?', [radius])
      .orderBy('distance', 'asc')
      .preload('provider', (query) => {
        query.select('id', 'fullName', 'organizationName', 'userType')
      })

    if (resource_type) {
      query.where('resourceType', resource_type)
    }

    const resources = await query

    return response.ok({
      message: 'Nearby resources retrieved successfully',
      data: resources
    })
  }

  /**
   * Get resource statistics
   */
  async statistics({ response }: HttpContext) {
    const totalResources = await Resource.query().count('* as total')
    const availableResources = await Resource.query().where('status', 'available').count('* as total')
    const distributedResources = await Resource.query().where('status', 'distributed').count('* as total')
    
    const resourcesByType = await Resource.query()
      .select('resourceType')
      .count('* as count')
      .groupBy('resourceType')

    return response.ok({
      message: 'Resource statistics retrieved successfully',
      data: {
        total: totalResources[0].$extras.total,
        available: availableResources[0].$extras.total,
        distributed: distributedResources[0].$extras.total,
        byType: resourcesByType
      }
    })
  }
}