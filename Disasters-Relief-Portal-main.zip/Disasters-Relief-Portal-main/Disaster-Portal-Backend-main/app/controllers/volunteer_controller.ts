import type { HttpContext } from '@adonisjs/core/http'
import VolunteerAssignment from '#models/volunteer_assignment'
import Notification from '#models/notification'
import { createVolunteerAssignmentValidator, updateVolunteerAssignmentValidator } from '../validators/volunteer_assignment.ts'
import { DateTime } from 'luxon'

export default class VolunteerController {
  /**
   * Get all volunteer assignments with pagination and filters
   */
  async index({ request, response }: HttpContext) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const taskType = request.input('task_type')
    const status = request.input('status')
    const priority = request.input('priority')
    const disasterId = request.input('disaster_id')

    const query = VolunteerAssignment.query()
      .preload('volunteer', (query) => {
        query.select('id', 'fullName', 'email', 'phone', 'skills')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state', 'status')
      })
      .preload('creator', (query) => {
        query.select('id', 'fullName', 'organizationName')
      })
      .orderBy('createdAt', 'desc')

    if (taskType) query.where('taskType', taskType)
    if (status) query.where('status', status)
    if (priority) query.where('priority', priority)
    if (disasterId) query.where('disasterId', disasterId)

    const assignments = await query.paginate(page, limit)

    return response.ok({
      message: 'Volunteer assignments retrieved successfully',
      data: assignments
    })
  }

  /**
   * Create a new volunteer assignment (for NGOs)
   */
  async store({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'ngo') {
      return response.forbidden({
        message: 'Only NGOs can create volunteer assignments'
      })
    }

    const data = await request.validateUsing(createVolunteerAssignmentValidator)

    const assignment = await VolunteerAssignment.create({
      ...data,
      createdBy: user.id,
      status: 'open',
      volunteersAssigned: 0,
      startDate: data.startDate ? DateTime.fromJSDate(data.startDate) : undefined,
      endDate: data.endDate ? DateTime.fromJSDate(data.endDate) : undefined
    })

    // Create notification for volunteer assignment
    await Notification.create({
      title: `New Volunteer Assignment: ${assignment.title}`,
      message: `Help needed with ${assignment.taskType} in ${assignment.location}`,
      type: 'volunteer_assignment',
      priority: assignment.priority === 'urgent' ? 'critical' : 'high',
      targetAudience: 'volunteers',
      disasterId: assignment.disasterId,
      sentBy: user.id,
      isRead: false
    })

    await assignment.load('disaster')
    await assignment.load('creator')

    return response.created({
      message: 'Volunteer assignment created successfully',
      data: assignment
    })
  }

  /**
   * Get volunteer assignment by ID
   */
  async show({ params, response }: HttpContext) {
    const assignment = await VolunteerAssignment.query()
      .where('id', params.id)
      .preload('volunteer', (query) => {
        query.select('id', 'fullName', 'email', 'phone', 'skills')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state', 'status', 'disasterType')
      })
      .preload('creator', (query) => {
        query.select('id', 'fullName', 'organizationName', 'email', 'phone')
      })
      .firstOrFail()

    return response.ok({
      message: 'Volunteer assignment retrieved successfully',
      data: assignment
    })
  }

  /**
   * Update volunteer assignment
   */
  async update({ auth, params, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const assignment = await VolunteerAssignment.findOrFail(params.id)

    // Only the creator can update the assignment
    if (assignment.createdBy !== user.id) {
      return response.forbidden({
        message: 'You can only update your own volunteer assignments'
      })
    }

    const data = await request.validateUsing(updateVolunteerAssignmentValidator)
    assignment.merge({
      ...data,
      startDate: data.startDate ? DateTime.fromJSDate(data.startDate) : undefined,
      endDate: data.endDate ? DateTime.fromJSDate(data.endDate) : undefined
    })
    await assignment.save()

    await assignment.load('volunteer')
    await assignment.load('disaster')
    await assignment.load('creator')

    return response.ok({
      message: 'Volunteer assignment updated successfully',
      data: assignment
    })
  }

  /**
   * Apply for volunteer assignment
   */
  async apply({ auth, params, response }: HttpContext) {
    const user = auth.getUserOrFail()
    
    if (user.userType !== 'volunteer') {
      return response.forbidden({
        message: 'Only volunteers can apply for assignments'
      })
    }

    const assignment = await VolunteerAssignment.findOrFail(params.id)

    if (assignment.status !== 'open') {
      return response.badRequest({
        message: 'This assignment is no longer open for applications'
      })
    }

    if (assignment.volunteersAssigned >= assignment.volunteersNeeded) {
      return response.badRequest({
        message: 'This assignment already has enough volunteers'
      })
    }

    // Check if user already applied
    const existingAssignment = await VolunteerAssignment.query()
      .where('id', params.id)
      .where('volunteerId', user.id)
      .first()

    if (existingAssignment) {
      return response.badRequest({
        message: 'You have already applied for this assignment'
      })
    }

    assignment.volunteerId = user.id
    assignment.volunteersAssigned += 1
    assignment.assignedAt = DateTime.fromJSDate(new Date())
    
    if (assignment.volunteersAssigned >= assignment.volunteersNeeded) {
      assignment.status = 'assigned'
    }

    await assignment.save()

    // Create notification for assignment creator
    await Notification.create({
      title: `Volunteer Applied: ${assignment.title}`,
      message: `${user.fullName} has applied for the volunteer assignment "${assignment.title}"`,
      type: 'volunteer_assignment',
      priority: 'medium',
      targetAudience: 'specific_users',
      recipientId: assignment.createdBy,
      disasterId: assignment.disasterId,
      sentBy: user.id,
      isRead: false
    })

    return response.ok({
      message: 'Application submitted successfully',
      data: assignment
    })
  }

  /**
   * Mark assignment as completed
   */
  async complete({ auth, params, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const assignment = await VolunteerAssignment.findOrFail(params.id)

    // Only the assigned volunteer or creator can mark as completed
    if (assignment.volunteerId !== user.id && assignment.createdBy !== user.id) {
      return response.forbidden({
        message: 'You are not authorized to complete this assignment'
      })
    }

    assignment.status = 'completed'
    assignment.completedAt = DateTime.fromJSDate(new Date())
    await assignment.save()

    // Create notification
    const recipientId = assignment.volunteerId === user.id ? assignment.createdBy : assignment.volunteerId
    await Notification.create({
      title: `Assignment Completed: ${assignment.title}`,
      message: `The volunteer assignment "${assignment.title}" has been marked as completed`,
      type: 'volunteer_assignment',
      priority: 'medium',
      targetAudience: 'specific_users',
      recipientId: recipientId,
      disasterId: assignment.disasterId,
      sentBy: user.id,
      isRead: false
    })

    return response.ok({
      message: 'Assignment marked as completed',
      data: assignment
    })
  }

  /**
   * Get volunteer assignments for current user
   */
  async myAssignments({ auth, request, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const page = request.input('page', 1)
    const limit = request.input('limit', 20)
    const status = request.input('status')

    let query

    if (user.userType === 'volunteer') {
      query = VolunteerAssignment.query().where('volunteerId', user.id)
    } else if (user.userType === 'ngo') {
      query = VolunteerAssignment.query().where('createdBy', user.id)
    } else {
      return response.forbidden({
        message: 'Only volunteers and NGOs can view assignments'
      })
    }

    if (status) {
      query.where('status', status)
    }

    const assignments = await query
      .preload('volunteer', (query) => {
        query.select('id', 'fullName', 'email', 'phone')
      })
      .preload('disaster', (query) => {
        query.select('id', 'title', 'city', 'state')
      })
      .preload('creator', (query) => {
        query.select('id', 'fullName', 'organizationName')
      })
      .orderBy('createdAt', 'desc')
      .paginate(page, limit)

    return response.ok({
      message: 'User assignments retrieved successfully',
      data: assignments
    })
  }

  /**
   * Get volunteer assignment statistics
   */
  async statistics({ response }: HttpContext) {
    const totalAssignments = await VolunteerAssignment.query().count('* as total')
    const openAssignments = await VolunteerAssignment.query().where('status', 'open').count('* as total')
    const completedAssignments = await VolunteerAssignment.query().where('status', 'completed').count('* as total')
    
    const assignmentsByType = await VolunteerAssignment.query()
      .select('taskType')
      .count('* as count')
      .groupBy('taskType')

    const assignmentsByPriority = await VolunteerAssignment.query()
      .select('priority')
      .count('* as count')
      .groupBy('priority')

    return response.ok({
      message: 'Volunteer assignment statistics retrieved successfully',
      data: {
        total: totalAssignments[0].$extras.total,
        open: openAssignments[0].$extras.total,
        completed: completedAssignments[0].$extras.total,
        byType: assignmentsByType,
        byPriority: assignmentsByPriority
      }
    })
  }
}