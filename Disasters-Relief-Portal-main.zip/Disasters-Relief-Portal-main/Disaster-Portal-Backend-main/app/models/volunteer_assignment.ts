import { DateTime } from 'luxon'
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm'
import type { BelongsTo } from '@adonisjs/lucid/types/relations'
import User from './user.js'
import Disaster from './disaster.js'

export default class VolunteerAssignment extends BaseModel {
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare title: string

  @column()
  declare description: string

  @column()
  declare taskType: 'rescue' | 'medical_aid' | 'food_distribution' | 'shelter_setup' | 'cleanup' | 'coordination' | 'other'

  @column()
  declare priority: 'low' | 'medium' | 'high' | 'urgent'

  @column()
  declare status: 'open' | 'assigned' | 'in_progress' | 'completed' | 'cancelled'

  @column()
  declare requiredSkills: string | null // JSON array of skills

  @column()
  declare volunteersNeeded: number

  @column()
  declare volunteersAssigned: number

  @column()
  declare location: string

  @column()
  declare latitude: number | null

  @column()
  declare longitude: number | null

  @column.dateTime()
  declare startDate: DateTime

  @column.dateTime()
  declare endDate: DateTime | null

  @column()
  declare contactPerson: string

  @column()
  declare contactPhone: string

  @column()
  declare volunteerId: number | null

  @column()
  declare disasterId: number

  @column()
  declare createdBy: number

  @column.dateTime()
  declare assignedAt: DateTime | null

  @column.dateTime()
  declare completedAt: DateTime | null

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @belongsTo(() => User, { foreignKey: 'volunteerId' })
  declare volunteer: BelongsTo<typeof User>

  @belongsTo(() => Disaster)
  declare disaster: BelongsTo<typeof Disaster>

  @belongsTo(() => User, { foreignKey: 'createdBy' })
  declare creator: BelongsTo<typeof User>
}