import { DateTime } from 'luxon'
import { BaseModel, column, belongsTo, hasMany } from '@adonisjs/lucid/orm'
import type { BelongsTo, HasMany } from '@adonisjs/lucid/types/relations'
import User from './user.js'
import Resource from './resource.ts'
import VolunteerAssignment from './volunteer_assignment.ts'

export default class Disaster extends BaseModel {
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare title: string

  @column()
  declare description: string

  @column()
  declare disasterType: 'flood' | 'earthquake' | 'fire' | 'hurricane' | 'tornado' | 'tsunami' | 'other'

  @column()
  declare severity: 'low' | 'medium' | 'high' | 'critical'

  @column()
  declare status: 'reported' | 'verified' | 'active' | 'resolved'

  @column()
  declare latitude: number

  @column()
  declare longitude: number

  @column()
  declare address: string

  @column()
  declare city: string

  @column()
  declare state: string

  @column()
  declare affectedPeople: number | null

  @column()
  declare estimatedDamage: number | null

  @column()
  declare images: string | null // JSON array of image URLs

  @column()
  declare reportedBy: number

  @column()
  declare verifiedBy: number | null

  @column.dateTime()
  declare verifiedAt: DateTime | null

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @belongsTo(() => User, { foreignKey: 'reportedBy' })
  declare reporter: BelongsTo<typeof User>

  @belongsTo(() => User, { foreignKey: 'verifiedBy' })
  declare verifier: BelongsTo<typeof User>

  @hasMany(() => Resource)
  declare resources: HasMany<typeof Resource>

  @hasMany(() => VolunteerAssignment)
  declare volunteerAssignments: HasMany<typeof VolunteerAssignment>
    disaster!: Date
    static $knex: any
}