import { DateTime } from 'luxon'
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm'
import type { BelongsTo } from '@adonisjs/lucid/types/relations'
import User from './user.js'
import Disaster from './disaster.js'

export default class Donation extends BaseModel {
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare donationType: 'money' | 'food' | 'clothing' | 'medical' | 'shelter' | 'other'

  @column()
  declare amount: number | null // For monetary donations

  @column()
  declare currency: string | null // e.g., 'USD', 'INR'

  @column()
  declare description: string | null

  @column()
  declare quantity: number | null // For non-monetary donations

  @column()
  declare unit: string | null

  @column()
  declare status: 'pending' | 'completed' | 'failed' | 'refunded'

  @column()
  declare paymentMethod: string | null // e.g., 'credit_card', 'paypal', 'bank_transfer'

  @column()
  declare transactionId: string | null

  @column()
  declare isAnonymous: boolean

  @column()
  declare donorName: string | null

  @column()
  declare donorEmail: string | null

  @column()
  declare donorPhone: string | null

  @column()
  declare donatedBy: number | null

  @column()
  declare disasterId: number | null

  @column()
  declare organizationId: number | null // NGO receiving the donation

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @belongsTo(() => User, { foreignKey: 'donatedBy' })
  declare donor: BelongsTo<typeof User>

  @belongsTo(() => Disaster)
  declare disaster: BelongsTo<typeof Disaster>

  @belongsTo(() => User, { foreignKey: 'organizationId' })
  declare organization: BelongsTo<typeof User>
}