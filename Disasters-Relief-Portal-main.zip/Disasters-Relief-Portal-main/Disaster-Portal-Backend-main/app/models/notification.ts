import { DateTime } from 'luxon'
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm'
import type { BelongsTo } from '@adonisjs/lucid/types/relations'
import User from './user.js'
import Disaster from './disaster.js'

export default class Notification extends BaseModel {
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare title: string

  @column()
  declare message: string

  @column()
  declare type: 'disaster_alert' | 'resource_update' | 'volunteer_assignment' | 'donation_received' | 'general' | 'emergency'

  @column()
  declare priority: 'low' | 'medium' | 'high' | 'critical'

  @column()
  declare targetAudience: 'all' | 'citizens' | 'ngos' | 'volunteers' | 'specific_users'

  @column()
  declare recipientId: number | null // Specific user if targetAudience is 'specific_users'

  @column()
  declare disasterId: number | null

  @column()
  declare isRead: boolean

  @column()
  declare sentBy: number

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @belongsTo(() => User, { foreignKey: 'recipientId' })
  declare recipient: BelongsTo<typeof User>

  @belongsTo(() => Disaster)
  declare disaster: BelongsTo<typeof Disaster>

  @belongsTo(() => User, { foreignKey: 'sentBy' })
  declare sender: BelongsTo<typeof User>
}