import { DateTime } from 'luxon'
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm'
import type { BelongsTo } from '@adonisjs/lucid/types/relations'
import User from './user.js'
import Disaster from './disaster.js'

export default class Resource extends BaseModel {
  static $knexRaw(arg0: string, arg1: any[]): "*" {
      throw new Error('Method not implemented.')
  }
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare title: string

  @column()
  declare description: string

  @column()
  declare resourceType: 'food' | 'shelter' | 'medical' | 'clothing' | 'water' | 'other'

  @column()
  declare quantity: number

  @column()
  declare unit: string // e.g., 'kg', 'liters', 'pieces', 'beds'

  @column()
  declare availableQuantity: number

  @column()
  declare status: 'available' | 'reserved' | 'distributed' | 'expired'

  @column()
  declare location: string

  @column()
  declare latitude: number | null

  @column()
  declare longitude: number | null

  @column()
  declare contactPerson: string

  @column()
  declare contactPhone: string

  @column()
  declare contactEmail: string | null

  @column.dateTime()
  declare expiryDate: DateTime | null

  @column()
  declare providedBy: number

  @column()
  declare disasterId: number | null

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime

  @belongsTo(() => User, { foreignKey: 'providedBy' })
  declare provider: BelongsTo<typeof User>

  @belongsTo(() => Disaster)
  declare disaster: BelongsTo<typeof Disaster>
}