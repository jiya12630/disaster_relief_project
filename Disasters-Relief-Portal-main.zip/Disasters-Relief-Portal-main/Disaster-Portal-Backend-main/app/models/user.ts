import { DateTime } from 'luxon'
import hash from '@adonisjs/core/services/hash'
import { compose } from '@adonisjs/core/helpers'
import { BaseModel, column, hasMany } from '@adonisjs/lucid/orm'
import { withAuthFinder } from '@adonisjs/auth/mixins/lucid'
import { DbAccessTokensProvider } from '@adonisjs/auth/access_tokens'
import type { HasMany } from '@adonisjs/lucid/types/relations'
import Disaster from './disaster.ts';
import Donation from './donation.ts';
import VolunteerAssignment from './volunteer_assignment.ts';

const AuthFinder = withAuthFinder(() => hash.use('scrypt'), {
  uids: ['email'],
  passwordColumnName: 'password',
})

export default class User extends compose(BaseModel, AuthFinder) {
  @column({ isPrimary: true })
  declare id: number

  @column()
  declare fullName: string | null

  @column()
  declare email: string

  @column({ serializeAs: null })
  declare password: string

  @column()
  declare userType: 'citizen' | 'ngo' | 'volunteer'

  @column()
  declare phone: string | null

  @column()
  declare address: string | null

  @column()
  declare organizationName: string | null

  @column()
  declare skills: string | null

  @column()
  declare isVerified: boolean

  @column.dateTime({ autoCreate: true })
  declare createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  declare updatedAt: DateTime | null

  @hasMany(() => Disaster)
  declare reportedDisasters: HasMany<typeof Disaster>

  @hasMany(() => Donation)
  declare donations: HasMany<typeof Donation>

  @hasMany(() => VolunteerAssignment)
  declare volunteerAssignments: HasMany<typeof VolunteerAssignment>

  static accessTokens = DbAccessTokensProvider.forModel(User)
}