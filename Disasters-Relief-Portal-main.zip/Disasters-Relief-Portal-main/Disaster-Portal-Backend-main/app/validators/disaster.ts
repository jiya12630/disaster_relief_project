import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new disaster report
 */
export const createDisasterValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(5).maxLength(200),
    description: vine.string().minLength(10).maxLength(1000),
    disasterType: vine.enum(['flood', 'earthquake', 'fire', 'hurricane', 'tornado', 'tsunami', 'other']),
    severity: vine.enum(['low', 'medium', 'high', 'critical']),
    latitude: vine.number().min(-90).max(90),
    longitude: vine.number().min(-180).max(180),
    address: vine.string().minLength(5).maxLength(255),
    city: vine.string().minLength(2).maxLength(100),
    state: vine.string().minLength(2).maxLength(100),
    affectedPeople: vine.number().optional(),
    estimatedDamage: vine.number().optional(),
    images: vine.string().optional()
  })
)

/**
 * Validator to validate the payload when updating
 * a disaster report
 */
export const updateDisasterValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(5).maxLength(200).optional(),
    description: vine.string().minLength(10).maxLength(1000).optional(),
    severity: vine.enum(['low', 'medium', 'high', 'critical']).optional(),
    status: vine.enum(['reported', 'verified', 'active', 'resolved']).optional(),
    affectedPeople: vine.number().min(0).optional(),
    estimatedDamage: vine.number().min(0).optional(),
    images: vine.string().optional()
  })
)