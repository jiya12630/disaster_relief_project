import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new user account
 */
export const registerValidator = vine.compile(
  vine.object({
    fullName: vine.string().minLength(2).maxLength(100),
    email: vine
      .string()
      .email()
      .normalizeEmail()
      .unique(async (db, value) => {
        const user = await db.from('users').where('email', value).first()
        return !user
      }),
    password: vine.string().minLength(8).maxLength(32),
    userType: vine.enum(['citizen', 'ngo', 'volunteer']),
    phone: vine.string().minLength(10).maxLength(15).optional(),
    address: vine.string().maxLength(255).optional(),
    organizationName: vine.string().maxLength(100).optional(),
    skills: vine.string().maxLength(500).optional()
  })
)

/**
 * Validator to validate the payload when logging in
 */
export const loginValidator = vine.compile(
  vine.object({
    email: vine.string().email().normalizeEmail(),
    password: vine.string()
  })
)