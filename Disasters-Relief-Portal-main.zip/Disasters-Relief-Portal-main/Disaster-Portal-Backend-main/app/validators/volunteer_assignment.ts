import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new volunteer assignment
 */
export const createVolunteerAssignmentValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(5).maxLength(200),
    description: vine.string().minLength(10).maxLength(1000),
    taskType: vine.enum(['rescue', 'medical_aid', 'food_distribution', 'shelter_setup', 'cleanup', 'coordination', 'other']),
    priority: vine.enum(['low', 'medium', 'high', 'urgent']),
    requiredSkills: vine.string().maxLength(500).optional(),
    volunteersNeeded: vine.number().min(1).max(100),
    location: vine.string().minLength(5).maxLength(255),
    latitude: vine.number().min(-90).max(90).optional(),
    longitude: vine.number().min(-180).max(180).optional(),
    startDate: vine.date(),
    endDate: vine.date().optional(),
    contactPerson: vine.string().minLength(2).maxLength(100),
    contactPhone: vine.string().minLength(10).maxLength(15),
    disasterId: vine.number().min(1)
  })
)

/**
 * Validator to validate the payload when updating
 * a volunteer assignment
 */
export const updateVolunteerAssignmentValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(5).maxLength(200).optional(),
    description: vine.string().minLength(10).maxLength(1000).optional(),
    priority: vine.enum(['low', 'medium', 'high', 'urgent']).optional(),
    status: vine.enum(['open', 'assigned', 'in_progress', 'completed', 'cancelled']).optional(),
    requiredSkills: vine.string().maxLength(500).optional(),
    volunteersNeeded: vine.number().min(1).max(100).optional(),
    location: vine.string().minLength(5).maxLength(255).optional(),
    startDate: vine.date().optional(),
    endDate: vine.date().optional(),
    contactPerson: vine.string().minLength(2).maxLength(100).optional(),
    contactPhone: vine.string().minLength(10).maxLength(15).optional()
  })
)