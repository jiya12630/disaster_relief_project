import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new donation
 */
export const createDonationValidator = vine.compile(
  vine.object({
    donationType: vine.enum(['money', 'food', 'clothing', 'medical', 'shelter', 'other']),
    amount: vine.number().min(0.01).optional(),
    currency: vine.string().minLength(3).maxLength(3).optional(),
    description: vine.string().minLength(5).maxLength(500).optional(),
    quantity: vine.number().min(1).optional(),
    unit: vine.string().minLength(1).maxLength(50).optional(),
    paymentMethod: vine.string().minLength(3).maxLength(50).optional(),
    isAnonymous: vine.boolean().optional(),
    donorName: vine.string().minLength(2).maxLength(100).optional(),
    donorEmail: vine.string().email().optional(),
    donorPhone: vine.string().minLength(10).maxLength(15).optional(),
    disasterId: vine.number().min(1).optional(),
    organizationId: vine.number().min(1).optional()
  })
)

/**
 * Validator to validate the payload when updating
 * a donation
 */
export const updateDonationValidator = vine.compile(
  vine.object({
    status: vine.enum(['pending', 'completed', 'failed', 'refunded']).optional(),
    paymentMethod: vine.string().minLength(3).maxLength(50).optional(),
    transactionId: vine.string().minLength(5).maxLength(100).optional()
  })
)