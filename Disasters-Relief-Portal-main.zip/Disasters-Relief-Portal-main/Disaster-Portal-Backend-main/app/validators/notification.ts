import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new notification
 */
export const createNotificationValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(5).maxLength(200),
    message: vine.string().minLength(10).maxLength(1000),
    type: vine.enum(['disaster_alert', 'resource_update', 'volunteer_assignment', 'donation_received', 'general', 'emergency']),
    priority: vine.enum(['low', 'medium', 'high', 'critical']),
    targetAudience: vine.enum(['all', 'citizens', 'ngos', 'volunteers', 'specific_users']),
    recipientId: vine.number().min(1).optional(),
    disasterId: vine.number().min(1).optional()
  })
)