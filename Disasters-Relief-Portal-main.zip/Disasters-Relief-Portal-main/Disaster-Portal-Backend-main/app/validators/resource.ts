import vine from '@vinejs/vine'

/**
 * Validator to validate the payload when creating
 * a new resource
 */
export const createResourceValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(3).maxLength(200),
    description: vine.string().minLength(10).maxLength(1000),
    resourceType: vine.enum(['food', 'shelter', 'medical', 'clothing', 'water', 'other']),
    quantity: vine.number().min(1),
    unit: vine.string().minLength(1).maxLength(50),
    location: vine.string().minLength(5).maxLength(255),
    latitude: vine.number().min(-90).max(90).optional(),
    longitude: vine.number().min(-180).max(180).optional(),
    contactPerson: vine.string().minLength(2).maxLength(100),
    contactPhone: vine.string().minLength(10).maxLength(15),
    contactEmail: vine.string().email().optional(),
    expiryDate: vine.date().optional(),
    disasterId: vine.number().min(1).optional()
  })
)

/**
 * Validator to validate the payload when updating
 * a resource
 */
export const updateResourceValidator = vine.compile(
  vine.object({
    title: vine.string().minLength(3).maxLength(200).optional(),
    description: vine.string().minLength(10).maxLength(1000).optional(),
    quantity: vine.number().min(1).optional(),
    availableQuantity: vine.number().min(0).optional(),
    status: vine.enum(['available', 'reserved', 'distributed', 'expired']).optional(),
    location: vine.string().minLength(5).maxLength(255).optional(),
    contactPerson: vine.string().minLength(2).maxLength(100).optional(),
    contactPhone: vine.string().minLength(10).maxLength(15).optional(),
    contactEmail: vine.string().email().optional(),
    expiryDate: vine.date().optional()
  })
)