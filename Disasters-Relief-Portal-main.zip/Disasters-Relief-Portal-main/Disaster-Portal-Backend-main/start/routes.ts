/*
|--------------------------------------------------------------------------
| Routes file
|--------------------------------------------------------------------------
|
| The routes file is used for defining the HTTP routes.
|
*/

import router from '@adonisjs/core/services/router'
import { middleware } from './kernel.js'

// Public routes
router.get('/', async () => {
  return {
    message: 'Disaster Relief Portal API',
    version: '1.0.0',
    status: 'active'
  }
})

// Authentication Routes
router.group(() => {
  router.post('/register', '#controllers/auth_controller.register')
  router.post('/login', '#controllers/auth_controller.login')
}).prefix('/api/auth')

// Protected routes (require authentication)
router.group(() => {
  // Auth routes (authenticated)
  router.group(() => {
    router.post('/logout', '#controllers/auth_controller.logout')
    router.get('/me', '#controllers/auth_controller.me')
    router.put('/profile', '#controllers/auth_controller.updateProfile')
  }).prefix('/auth')

  // Disaster routes
  router.group(() => {
    router.get('/', '#controllers/disaster_controller.index')
    router.post('/', '#controllers/disaster_controller.store')
    router.get('/statistics', '#controllers/disaster_controller.statistics')
    router.get('/nearby', '#controllers/disaster_controller.nearby')
    router.get('/:id', '#controllers/disaster_controller.show')
    router.put('/:id', '#controllers/disaster_controller.update')
  }).prefix('/disasters')

  // Resource routes
  router.group(() => {
    router.get('/', '#controllers/resource_controller.index')
    router.post('/', '#controllers/resource_controller.store')
    router.get('/statistics', '#controllers/resource_controller.statistics')
    router.get('/nearby', '#controllers/resource_controller.nearby')
    router.get('/:id', '#controllers/resource_controller.show')
    router.put('/:id', '#controllers/resource_controller.update')
    router.post('/:id/reserve', '#controllers/resource_controller.reserve')
  }).prefix('/resources')

  // Donation routes
  router.group(() => {
    router.get('/', '#controllers/donation_controller.index')
    router.post('/', '#controllers/donation_controller.store')
    router.get('/statistics', '#controllers/donation_controller.statistics')
    router.get('/my-donations', '#controllers/donation_controller.userDonations')
    router.get('/organization-donations', '#controllers/donation_controller.organizationDonations')
    router.get('/:id', '#controllers/donation_controller.show')
    router.put('/:id', '#controllers/donation_controller.update')
    router.post('/:id/process-payment', '#controllers/donation_controller.processPayment')
  }).prefix('/donations')

  // Volunteer Assignment routes
  router.group(() => {
    router.get('/', '#controllers/volunteer_controller.index')
    router.post('/', '#controllers/volunteer_controller.store')
    router.get('/statistics', '#controllers/volunteer_controller.statistics')
    router.get('/my-assignments', '#controllers/volunteer_controller.myAssignments')
    router.get('/:id', '#controllers/volunteer_controller.show')
    router.put('/:id', '#controllers/volunteer_controller.update')
    router.post('/:id/apply', '#controllers/volunteer_controller.apply')
    router.post('/:id/complete', '#controllers/volunteer_controller.complete')
  }).prefix('/volunteers')

  // Notification routes
  router.group(() => {
    router.get('/', '#controllers/notification_controller.index')
    router.post('/', '#controllers/notification_controller.store')
    router.get('/statistics', '#controllers/notification_controller.statistics')
    router.get('/unread-count', '#controllers/notification_controller.unreadCount')
    router.get('/emergency-alerts', '#controllers/notification_controller.emergencyAlerts')
    router.post('/broadcast', '#controllers/notification_controller.broadcast')
    router.post('/mark-all-read', '#controllers/notification_controller.markAllAsRead')
    router.post('/:id/mark-read', '#controllers/notification_controller.markAsRead')
  }).prefix('/notifications')

}).prefix('/api').use(middleware.auth())

// Public donation route (allows anonymous donations)
router.post('/api/donations/anonymous', '#controllers/donation_controller.store')

// Public emergency alerts (no authentication required)
router.get('/api/emergency-alerts', '#controllers/notification_controller.emergencyAlerts')
